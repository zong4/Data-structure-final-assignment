#include <stdio.h>
#include <windows.h>
int main()
{
    printf("Hello World\n");
    system("pause");
    return 0;
}