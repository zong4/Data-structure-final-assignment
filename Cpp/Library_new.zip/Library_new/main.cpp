#include<iostream>

#include"DataBase.h"

DataBase test(1000);

int main()
{
    cout<<1;
    return 0;
}
